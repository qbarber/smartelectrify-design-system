export const COLORS = {
  primary: '#0EA5E9', // Electric Blue
  secondary: '#10B981', // Forest Green
  accent: '#F59E0B', // Amber
  background: '#FFFFFF',
  text: '#0F172A', // Slate 900
  textMuted: '#64748B', // Slate 500
  border: '#E2E8F0', // Slate 200
  error: '#EF4444', // Red 500
  success: '#10B981' // Green 500
} as const;

export const SPACING = {
  xs: '8px',
  sm: '16px',
  md: '24px',
  lg: '32px',
  xl: '48px'
} as const;

export const TYPOGRAPHY = {
  h1: {
    fontSize: '2.5rem',
    fontWeight: '700',
    lineHeight: '1.2'
  },
  h2: {
    fontSize: '1.5rem',
    fontWeight: '600',
    lineHeight: '1.3'
  },
  body: {
    fontSize: '1rem',
    fontWeight: '400',
    lineHeight: '1.5'
  },
  small: {
    fontSize: '0.875rem',
    fontWeight: '400',
    lineHeight: '1.4'
  }
} as const;

export const EQUIPMENT_TYPES = {
  heat_pump: 'Heat Pump',
  solar: 'Solar Panels',
  battery: 'Battery Storage',
  panel_upgrade: 'Electrical Panel Upgrade'
} as const;

export const HEATING_TYPES = {
  gas: 'Natural Gas',
  oil: 'Heating Oil',
  electric: 'Electric'
} as const;